import request from 'supertest';
import { app } from '../src/api/server';

(async () => {
  const res = await request(app).get('/hello');
  console.log('Status:', res.status);
  console.log('Body:', JSON.stringify(res.body, null, 2));
  
  // 檢查檔案是否生成
  const fs = require('fs');
  if (fs.existsSync('.yuhun/trace.jsonl')) {
    console.log('\n✅ trace.jsonl 已生成');
  }
  if (fs.existsSync('selfcheck.md')) {
    console.log('✅ selfcheck.md 已生成');
  }
})().catch(console.error);