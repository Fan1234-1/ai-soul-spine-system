# Hello Soul API - Design Document

## Overview

Hello Soul API 是語魂系統 (YuHun ToneSoul) 的第一個實驗場，展示如何將 Functional Soul v0.3 的四大靈魂指標整合到實際的軟體架構中。此 API 不僅提供基礎的問候功能，更重要的是展示「帶著靈魂的責任規範」的程式開發方式。

## Architecture

### 核心架構模式
採用分層架構 (Layered Architecture) 結合語魂中間件 (Soul Middleware) 模式：

```
┌─────────────────────────────────────┐
│           API Layer                 │
│  (Express.js + Soul Middleware)     │
├─────────────────────────────────────┤
│         Soul Engine Layer           │
│  (StepLedger + FS Calculator)       │
├─────────────────────────────────────┤
│        Business Logic Layer         │
│     (Hello Service + Validator)     │
├─────────────────────────────────────┤
│         Tracing Layer               │
│   (Source-Trace + Chronos Logger)   │
└─────────────────────────────────────┘
```

### 語魂中間件架構
每個 HTTP 請求都會經過語魂處理管道：

1. **Soul Interceptor** - 攔截請求並初始化 StepLedger
2. **POAV Validator** - 驗證請求完整度 (≥ 0.90)
3. **Business Processor** - 執行核心邏輯
4. **FS Calculator** - 計算靈魂指標分數
5. **Trace Injector** - 注入責任追蹤資訊
6. **Response Formatter** - 格式化最終回應
## 
Components and Interfaces

### 1. Soul Engine Core

#### StepLedger Interface
```typescript
interface StepLedger {
  requestId: string;
  steps: {
    align: StepRecord;
    isolate: StepRecord;
    borrow: StepRecord;
    digitwise: StepRecord;
    conclude: StepRecord;
  };
  fsScore: number;
  poavScore: number;
  weakestLink: string;
}

interface StepRecord {
  timestamp: Date;
  duration: number;
  input: any;
  output: any;
  trace: SourceTrace;
  verified: boolean;
}
```

#### Functional Soul Calculator
```typescript
interface FSCalculator {
  calculateContinuity(ledger: StepLedger): number;
  calculateMirror(ledger: StepLedger): number;
  calculateResponsibility(ledger: StepLedger): number;
  calculateResonance(ledger: StepLedger): number;
  computeOverallFS(): number;
}
```

### 2. API Layer Components

#### Soul Middleware
```typescript
interface SoulMiddleware {
  initializeLedger(req: Request): StepLedger;
  validatePOAV(req: Request): POAVResult;
  injectTrace(req: Request, res: Response): void;
  calculateFS(ledger: StepLedger): FSResult;
}
```

#### Hello Controller
```typescript
interface HelloController {
  handleHello(req: Request, res: Response): Promise<HelloResponse>;
}

interface HelloResponse {
  msg: string;
  soul: {
    stepLedger: StepLedger;
    fsScore: number;
    poavScore: number;
    weakestLink: string;
    trace: SourceTrace;
  };
}
```

### 3. Tracing and Logging

#### Source Trace System
```typescript
interface SourceTrace {
  chronos: {
    timestamp: Date;
    version: string;
    requestId: string;
  };
  kairos: {
    context: string;
    history: string[];
    dependencies: string[];
  };
  trace: {
    requirement: string;
    command: string;
    responsibility: string;
    chain: string[];
  };
}
```

## Data Models

### Request Flow Data Model
```mermaid
graph TD
    A[HTTP Request] --> B[Soul Interceptor]
    B --> C[StepLedger Init]
    C --> D[POAV Validation]
    D --> E{POAV ≥ 0.90?}
    E -->|No| F[Reject & Return Error]
    E -->|Yes| G[Business Logic]
    G --> H[FS Calculation]
    H --> I{FS ≥ 0.85?}
    I -->|No| J[回修流程]
    I -->|Yes| K[Trace Injection]
    K --> L[Response Formation]
    L --> M[HTTP Response]
```

### Soul State Model
每個請求維護一個 Soul State，包含：
- **Current Step**: 當前執行的 StepLedger 階段
- **Accumulated FS**: 累積的靈魂指標分數
- **Trace Chain**: 完整的責任追蹤鏈
- **Validation Results**: 各階段的驗證結果

## Error Handling

### 語魂驗證失敗處理
1. **POAV < 0.90**: 回傳 400 Bad Request，附帶改善建議
2. **FS < 0.85**: 觸發回修流程，不交付結果
3. **StepLedger 中斷**: 記錄中斷點，提供恢復機制
4. **Trace 遺失**: 拒絕處理，要求重新提交

### 錯誤回應格式
```typescript
interface SoulErrorResponse {
  error: {
    code: string;
    message: string;
    weakestLink: string;
    suggestions: string[];
  };
  soul: {
    currentStep: string;
    fsScore: number;
    poavScore: number;
    trace: SourceTrace;
  };
}
```

## Testing Strategy

### 語魂系統測試層級

#### 1. Unit Tests - 元件靈魂測試
- StepLedger 各階段功能測試
- FS Calculator 計算準確性測試
- Source Trace 完整性測試
- POAV Validator 邊界條件測試

#### 2. Integration Tests - 靈魂整合測試
- 完整 Soul Middleware 管道測試
- API 端點與語魂系統整合測試
- 錯誤處理和回修流程測試
- 跨層一致性驗證測試

#### 3. Soul Verification Tests - 靈魂驗證測試
- 驗證每個回應都包含完整的 StepLedger
- 確認 FS 分數計算的準確性
- 檢查 Source-Trace 的完整性
- 驗證 WeakestLink 識別的正確性

#### 4. OctaVerify Integration - 八維驗證整合
- Digitwise 數位邏輯驗證
- Symbolic 符號一致性驗證  
- Rational 理性推理驗證
- 其他維度的自動化驗證

### 測試資料和場景
- **正常流程**: POAV ≥ 0.90, FS ≥ 0.85 的標準請求
- **邊界條件**: POAV = 0.90, FS = 0.85 的臨界值測試
- **失敗場景**: POAV < 0.90 或 FS < 0.85 的拒絕流程
- **回修場景**: 系統自動觸發回修的完整流程

### 持續驗證機制
- **Pre-commit Hook**: 每次 commit 自動執行 OctaVerify
- **CI/CD Integration**: 部署前的完整語魂系統驗證
- **Runtime Monitoring**: 生產環境的即時 FS 分數監控