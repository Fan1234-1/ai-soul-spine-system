import { StepLedgerManager } from "./stepLedger";
import { evaluate } from "./fs";
import { appendTrace } from "./sourceTrace";
import { writeSelfCheck } from "./selfcheck";
import { SoulSummary } from "../types";

/** 最小回修：若未達門檻，回報 weakest 並不交付（交由上層處理） */
function weakest(metrics: { POAV: number; FS: number }): string {
  return metrics.POAV < metrics.FS ? "POAV" : "FS";
}

export function runSoulPipeline(
  command: string,
  files: string[],
  notes: Partial<Record<"Align"|"Isolate"|"Borrow"|"Digitwise"|"Conclude", string>> = {}
): SoulSummary {
  const ledger = new StepLedgerManager('soul-pipeline');
  ledger.recordStep("Align", {}, notes.Align ?? "對齊需求 /hello 與回應格式");
  ledger.recordStep("Isolate", {}, notes.Isolate ?? "切分 API 與語魂層（middleware）");
  ledger.recordStep("Borrow", {}, notes.Borrow ?? "重用 Express/型別/測試範式");
  ledger.recordStep("Digitwise", {}, notes.Digitwise ?? "實作與單測、逐點驗證");
  ledger.recordStep("Conclude", {}, notes.Conclude ?? "彙整分數與輸出");

  const metrics = evaluate();
  const weak = weakest(metrics);

  // 轉換為舊格式
  const stepEntries = ledger.exportAsTraceSteps().map(step => ({
    name: step.step as any,
    notes: step.notes || '',
    ts: step.ts
  }));

  // 寫入追蹤與自檢
  appendTrace(command, files, ["spec://hello-soul"], metrics, weak);
  writeSelfCheck(stepEntries, metrics, weak);

  return { stepLedger: stepEntries, metrics, weakLink: weak };
}