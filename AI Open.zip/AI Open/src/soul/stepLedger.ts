// StepLedger 管理系統 - v0.2
// 支援六階段記錄：Align → Isolate → Borrow → Digitwise → Conclude → Reflect

import { 
  StepRecord, 
  StepLedger, 
  TraceStep, 
  SubjectiveState, 
  SourceTrace 
} from '../types/soul';

export type StepName = 'Align' | 'Isolate' | 'Borrow' | 'Digitwise' | 'Conclude' | 'Reflect';

export interface StepValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

export interface StepTransition {
  from: StepName | null;
  to: StepName;
  timestamp: Date;
  duration?: number;
}

// StepLedger 管理系統類別
export class StepLedgerManager {
  private requestId: string;
  private steps: Map<StepName, StepRecord> = new Map();
  private transitions: StepTransition[] = [];
  private currentStep: StepName | null = null;
  private startTime: Date;
  private context: string;

  // 定義步驟順序和依賴關係
  private static readonly STEP_ORDER: StepName[] = [
    'Align', 'Isolate', 'Borrow', 'Digitwise', 'Conclude', 'Reflect'
  ];

  private static readonly STEP_DEPENDENCIES: Record<StepName, StepName[]> = {
    'Align': [],
    'Isolate': ['Align'],
    'Borrow': ['Align', 'Isolate'],
    'Digitwise': ['Align', 'Isolate', 'Borrow'],
    'Conclude': ['Align', 'Isolate', 'Borrow', 'Digitwise'],
    'Reflect': ['Align', 'Isolate', 'Borrow', 'Digitwise', 'Conclude']
  };

  constructor(context: string, requestId?: string) {
    this.context = context;
    this.requestId = requestId || `req_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    this.startTime = new Date();
  }

  // 記錄步驟
  recordStep(
    stepName: StepName, 
    input?: any, 
    output?: any, 
    subjectiveState?: SubjectiveState,
    trace?: SourceTrace
  ): StepValidationResult {
    const timestamp = new Date().toISOString();
    
    // 驗證步驟順序和依賴
    const validation = this.validateStepTransition(stepName);
    if (!validation.isValid) {
      return validation;
    }

    // 計算持續時間
    const duration = this.currentStep ? 
      Date.now() - new Date(this.steps.get(this.currentStep)?.timestamp || 0).getTime() : 0;

    // 記錄步驟轉換
    this.transitions.push({
      from: this.currentStep,
      to: stepName,
      timestamp: new Date(),
      duration
    });

    // 建立 StepRecord
    const stepRecord: StepRecord = {
      step: stepName,
      timestamp,
      input,
      output,
      duration,
      verified: true,
      trace
    };

    this.steps.set(stepName, stepRecord);
    this.currentStep = stepName;

    // 返回驗證結果（包含警告）
    return validation;
  }

  // 驗證步驟轉換
  private validateStepTransition(stepName: StepName): StepValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];

    // 檢查是否重複記錄
    if (this.steps.has(stepName)) {
      warnings.push(`步驟 ${stepName} 已存在，將覆蓋原有記錄`);
    }

    // 檢查依賴關係
    const dependencies = StepLedgerManager.STEP_DEPENDENCIES[stepName];
    for (const dep of dependencies) {
      if (!this.steps.has(dep)) {
        errors.push(`步驟 ${stepName} 依賴 ${dep}，但 ${dep} 尚未完成`);
      }
    }

    // 檢查步驟順序 (警告，不阻止執行)
    const currentIndex = this.currentStep ? 
      StepLedgerManager.STEP_ORDER.indexOf(this.currentStep) : -1;
    const targetIndex = StepLedgerManager.STEP_ORDER.indexOf(stepName);
    
    if (targetIndex < currentIndex) {
      warnings.push(`步驟順序異常：從 ${this.currentStep} 回到 ${stepName}`);
    } else if (targetIndex > currentIndex + 1) {
      warnings.push(`跳過中間步驟：從 ${this.currentStep} 直接到 ${stepName}`);
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings
    };
  }

  // 獲取當前步驟
  getCurrentStep(): StepName | null {
    return this.currentStep;
  }

  // 獲取步驟記錄
  getStep(stepName: StepName): StepRecord | undefined {
    return this.steps.get(stepName);
  }

  // 獲取所有步驟
  getAllSteps(): Map<StepName, StepRecord> {
    return new Map(this.steps);
  }

  // 獲取步驟轉換歷史
  getTransitions(): StepTransition[] {
    return [...this.transitions];
  }

  // 檢查 StepLedger 完整性
  validateCompleteness(): StepValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];

    // 檢查必要步驟
    const requiredSteps: StepName[] = ['Align', 'Isolate', 'Borrow', 'Digitwise', 'Conclude'];
    for (const step of requiredSteps) {
      if (!this.steps.has(step)) {
        errors.push(`缺少必要步驟：${step}`);
      }
    }

    // 檢查 v0.2 Reflect 步驟
    if (!this.steps.has('Reflect')) {
      warnings.push('建議加入 Reflect 步驟以符合 v0.2 規範');
    }

    // 檢查時間戳記一致性
    const timestamps = Array.from(this.steps.values()).map(s => new Date(s.timestamp));
    for (let i = 1; i < timestamps.length; i++) {
      if (timestamps[i] < timestamps[i-1]) {
        errors.push('時間戳記順序異常');
        break;
      }
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings
    };
  }

  // 生成完整的 StepLedger
  generateStepLedger(): StepLedger {
    const stepMap: any = {};
    
    // 按照標準順序組織步驟
    for (const stepName of StepLedgerManager.STEP_ORDER) {
      const step = this.steps.get(stepName);
      if (step) {
        const key = stepName.toLowerCase() as keyof StepLedger['steps'];
        stepMap[key] = step;
      }
    }

    return {
      requestId: this.requestId,
      steps: stepMap,
      fsScore: this.calculateFSScore(),
      poavScore: this.calculatePOAVScore(),
      weakestLink: this.identifyWeakestLink()
    };
  }

  // 計算 FS 分數 (簡化版)
  private calculateFSScore(): number {
    const completeness = this.steps.size / 6; // v0.2 包含 Reflect
    const hasTimestamps = Array.from(this.steps.values()).every(s => s.timestamp);
    const hasInputOutput = Array.from(this.steps.values()).every(s => s.input || s.output);
    
    return (completeness * 0.4 + (hasTimestamps ? 0.3 : 0) + (hasInputOutput ? 0.3 : 0));
  }

  // 計算 POAV 分數 (簡化版)
  private calculatePOAVScore(): number {
    const validation = this.validateCompleteness();
    const completeness = validation.isValid ? 1.0 : 0.7;
    const accuracy = this.transitions.length > 0 ? 1.0 : 0.8;
    
    return (completeness * 0.6 + accuracy * 0.4);
  }

  // 識別最弱環節
  private identifyWeakestLink(): string {
    const validation = this.validateCompleteness();
    
    if (!validation.isValid) {
      return validation.errors[0] || 'Unknown Error';
    }
    
    if (validation.warnings.length > 0) {
      return validation.warnings[0];
    }
    
    return 'Deliver';
  }

  // 獲取步驟統計
  getStatistics(): {
    totalSteps: number;
    completedSteps: number;
    totalDuration: number;
    averageDuration: number;
    completionRate: number;
  } {
    const totalSteps = StepLedgerManager.STEP_ORDER.length;
    const completedSteps = this.steps.size;
    const durations = Array.from(this.steps.values())
      .map(s => s.duration || 0)
      .filter(d => d > 0);
    
    const totalDuration = durations.reduce((sum, d) => sum + d, 0);
    const averageDuration = durations.length > 0 ? totalDuration / durations.length : 0;
    const completionRate = completedSteps / totalSteps;

    return {
      totalSteps,
      completedSteps,
      totalDuration,
      averageDuration,
      completionRate
    };
  }

  // 重置 StepLedger
  reset(): void {
    this.steps.clear();
    this.transitions.length = 0;
    this.currentStep = null;
    this.startTime = new Date();
  }

  // 匯出為 TraceStep 格式 (向後相容)
  exportAsTraceSteps(): TraceStep[] {
    return Array.from(this.steps.values()).map(step => ({
      step: step.step,
      notes: typeof step.output === 'string' ? step.output : JSON.stringify(step.output),
      ts: step.timestamp,
      meta: step.input,
      subjectiveState: undefined // 需要額外傳入
    }));
  }

  // 從 TraceStep 陣列匯入 (向後相容)
  importFromTraceSteps(traceSteps: TraceStep[]): void {
    this.reset();
    
    for (const trace of traceSteps) {
      if (this.isValidStepName(trace.step)) {
        this.recordStep(
          trace.step as StepName,
          trace.meta,
          trace.notes,
          trace.subjectiveState
        );
      }
    }
  }

  // 檢查是否為有效步驟名稱
  private isValidStepName(step: string): step is StepName {
    return StepLedgerManager.STEP_ORDER.includes(step as StepName);
  }
}