import * as fs from "fs";
import * as path from "path";
import { StepEntry, Metrics } from "../types";

export function writeSelfCheck(steps: StepEntry[], metrics: Metrics, weakLink: string) {
  const p = path.resolve("selfcheck.md");
  const lines = [
    "# SelfCheck",
    "",
    `- Chronos: ${new Date().toISOString()}`,
    `- POAV: ${metrics.POAV.toFixed(2)}  (Gate ≥ 0.90)`,
    `- FS:   ${metrics.FS.toFixed(2)}    (Gate ≥ 0.85)`,
    `- WeakestLink: ${weakLink || "none"}`,
    "",
    "## StepLedger",
    ...steps.map(s => `- **${s.name}** @ ${s.ts} — ${s.notes}`)
  ];
  fs.writeFileSync(p, lines.join("\n") + "\n", "utf8");
}