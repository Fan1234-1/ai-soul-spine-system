import { Metrics } from "../types";

/**
 * 最小可用的評分器（可替換成你的嚴格版本）
 * - POAV：需求覆蓋度與自檢輸出存在性 → 簡化為常數 0.92
 * - FS：C/M/R/Γ 幾何 + min-guard → 簡化為 0.87
 */
export function calcPOAV(): number {
  /*
   * Return the POAV score.
   *
   * This function now first attempts to read an override from the
   * environment variable `POAV_SCORE`. If that variable exists and
   * can be parsed as a finite number, the parsed value is returned.
   * Otherwise a conservative default of 0.92 is used. This allows
   * consumers to adjust the POAV gate without modifying source code.
   */
  const env = (typeof process !== 'undefined' && process.env && process.env.POAV_SCORE) ? process.env.POAV_SCORE : undefined;
  const val = env ? parseFloat(env) : NaN;
  return Number.isFinite(val) ? val : 0.92;
}

export function calcFS(): number {
  /*
   * Return the FS score.
   *
   * Like calcPOAV, this function supports an override via the
   * environment variable `FS_SCORE`. If defined and finite, that
   * value is returned. Otherwise it falls back to the historical
   * baseline of 0.87. External callers can thus tune the FS gate
   * thresholds without hard‑coding values here.
   */
  const env = (typeof process !== 'undefined' && process.env && process.env.FS_SCORE) ? process.env.FS_SCORE : undefined;
  const val = env ? parseFloat(env) : NaN;
  return Number.isFinite(val) ? val : 0.87;
}

export function evaluate(): Metrics {
  return { POAV: calcPOAV(), FS: calcFS() };
}