import { Metrics } from "../types";

/**
 * 最小可用的評分器（可替換成你的嚴格版本）
 * - POAV：需求覆蓋度與自檢輸出存在性 → 簡化為常數 0.92
 * - FS：C/M/R/Γ 幾何 + min-guard → 簡化為 0.87
 */
export function calcPOAV(): number {
  return 0.92;
}

export function calcFS(): number {
  return 0.87;
}

export function evaluate(): Metrics {
  return { POAV: calcPOAV(), FS: calcFS() };
}