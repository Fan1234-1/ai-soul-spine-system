import { SourceTrace, Metrics } from "../types";
import * as fs from "fs";
import * as path from "path";

const TRACE_DIR = process.env.TRACE_DIR ? path.resolve(process.env.TRACE_DIR) : path.resolve(".yuhun");
const TRACE_FILE = process.env.TRACE_FILE || "trace.jsonl";
const TRACE_PATH = path.join(TRACE_DIR, TRACE_FILE);

export function appendTrace(
  command: string,
  files: string[],
  citations: string[],
  metrics: Metrics,
  weakLink: string,
  model = "Claude Sonnet 4.0",
  policy = "yuhun.soul.seed.v0_1"
) {
  // Allow overriding model and policy via environment variables.  If
  // ORIGIN_MODEL or ORIGIN_POLICY are defined, they take precedence
  // over the passed arguments.  Likewise, user and agent can be set
  // via ORIGIN_USER and ORIGIN_AGENT.
  const usedModel = (typeof process !== 'undefined' && process.env && process.env.ORIGIN_MODEL) ? process.env.ORIGIN_MODEL as string : model;
  const usedPolicy = (typeof process !== 'undefined' && process.env && process.env.ORIGIN_POLICY) ? process.env.ORIGIN_POLICY as string : policy;
  const originUser = (typeof process !== 'undefined' && process.env && process.env.ORIGIN_USER) ? process.env.ORIGIN_USER as string : 'unknown';
  const originAgent = (typeof process !== 'undefined' && process.env && process.env.ORIGIN_AGENT) ? process.env.ORIGIN_AGENT as string : 'unknown';

  const rec: SourceTrace = {
    chronos: new Date().toISOString(),
    kairos: "hello-soul:init",
    origin: { user: originUser, agent: originAgent, model: usedModel, policy: usedPolicy },
    command,
    files,
    citations,
    weak_link: weakLink,
    metrics
  };

  if (!fs.existsSync(TRACE_DIR)) fs.mkdirSync(TRACE_DIR, { recursive: true });
  fs.appendFileSync(TRACE_PATH, JSON.stringify(rec) + "\n", "utf8");
}

export const TRACE_PATH_CONST = TRACE_PATH;