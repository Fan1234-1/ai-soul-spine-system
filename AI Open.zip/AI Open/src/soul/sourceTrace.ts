import { SourceTrace, Metrics } from "../types";
import * as fs from "fs";
import * as path from "path";

const TRACE_DIR = path.resolve(".yuhun");
const TRACE_PATH = path.join(TRACE_DIR, "trace.jsonl");

export function appendTrace(
  command: string,
  files: string[],
  citations: string[],
  metrics: Metrics,
  weakLink: string,
  model = "Claude Sonnet 4.0",
  policy = "yuhun.soul.seed.v0_1"
) {
  const rec: SourceTrace = {
    chronos: new Date().toISOString(),
    kairos: "hello-soul:init",
    origin: { user: "黃梵威", agent: "Kiro", model, policy },
    command,
    files,
    citations,
    weak_link: weakLink,
    metrics
  };

  if (!fs.existsSync(TRACE_DIR)) fs.mkdirSync(TRACE_DIR, { recursive: true });
  fs.appendFileSync(TRACE_PATH, JSON.stringify(rec) + "\n", "utf8");
}

export const TRACE_PATH_CONST = TRACE_PATH;