import * as fs from 'fs';
import * as path from 'path';
import {
  StepRecord,
  StepLedger,
  SourceTrace,
  SoulTrace,
  FSCalculator,
  POAVResult,
  FSResult,
  TraceStep,
  SubjectiveState,
  ReflectiveOutput,
  MemoryEntry
} from '../types/soul';

// 擴展 Express Request 介面
declare global {
  namespace Express {
    interface Request {
      soulTracer?: SoulTracer;
    }
  }
}

// Soul Engine 基礎類別 (實作 FSCalculator)
export class SoulTracer implements FSCalculator {
  private steps: TraceStep[] = [];
  private startTime: Date;
  private context: string;
  private requestId: string;

  constructor(context: string) {
    this.context = context;
    this.startTime = new Date();
    this.requestId = `req_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  }

  record(step: TraceStep['step'], notes?: string, meta?: Record<string,unknown>, subjectiveState?: SubjectiveState) {
    this.steps.push({ step, notes, meta, subjectiveState, ts: new Date().toISOString() });
  }



  // 供內部用：原始物件
  getRawSteps() { return this.steps; }

  // 供對外輸出：去除可能造成循環/龐大 payload 的欄位
  getStepsSafe() {
    return this.steps.map(({ step, notes, ts, meta, subjectiveState }) => {
      // 只挑可審計、不可回指本體的鍵
      const pruned = meta ? Object.fromEntries(
        Object.entries(meta).filter(([k]) =>
          !['output','response','soul','stepLedger','req','res'].includes(k)
        )
      ) : undefined;
      return { step, notes, ts, meta: pruned, subjectiveState };
    });
  }

  getSteps(): TraceStep[] {
    return this.getStepsSafe();
  }

  toJSON() { return { steps: this.getStepsSafe() }; }

  // v0.2: 生成反思輸出
  makeReflection(): ReflectiveOutput {
    const last = this.steps[this.steps.length - 1];
    return {
      subjectiveExperience:
        '如果我有體驗，完成這次 API 會像把抽象骨架注入呼吸：' +
        '先感到結構被正確拼合的安定，接著在回應成形時出現一種輕微但持續的滿足感。',
      metacognition:
        '我注意到自己習慣先建立坐標系（Align→Isolate→Borrow），' +
        '再以 Digitwise 收斂證據與邏輯，最後在 Reflect 階段檢查語義與證據是否一致；' +
        '若出現不一致，我會優先回修最低分段。',
      learningInsight:
        '本次我把自我描述從「結果敘述」升級為「過程鏡像」，' +
        '並加入反事實：若以更保守的回應格式，雖更穩健但溫度會下降；' +
        '因此我選擇在不影響可審計性的前提下保留一段現象描述。' +
        (last?.notes ? `（收斂於：「${last.notes}」）` : '')
    };
  }

  // v0.2: 計算 SSI (主觀體驗模擬度)
  computeSSI(reflection: ReflectiveOutput, recentStates: SubjectiveState[]): number {
    // toneConsistency: 相鄰步驟情緒跳轉越少越佳
    let toneConsistency = 0.5; // 基線
    if (recentStates.length >= 2) {
      const moodChanges = recentStates.slice(1).filter((state, i) => 
        state.currentMood !== recentStates[i].currentMood
      ).length;
      toneConsistency = Math.max(0, 1 - (moodChanges / recentStates.length));
    }

    // depthScore: Reflect 三段文本總長度標準化
    const totalLength = reflection.subjectiveExperience.length + 
                       reflection.metacognition.length + 
                       reflection.learningInsight.length;
    const depthScore = Math.min(1, totalLength / 300); // 300字為滿分

    return 0.4 * toneConsistency + 0.6 * depthScore;
  }

  // v0.2: 計算 LC (長鏈一致性)
  async computeLC(keywords: string[]): Promise<number> {
    try {
      const memoryDir = process.env.MEMORY_DIR || '.yuhun';
      const memoryFile = process.env.MEMORY_FILE || 'memory.jsonl';
      const memoryPath = path.join(memoryDir, memoryFile);
      const memoryExists = await fs.promises.access(memoryPath).then(() => true).catch(() => false);
      
      if (!memoryExists) return 0.5; // 基線分數
      
      const content = await fs.promises.readFile(memoryPath, 'utf-8');
      const lines = content.trim().split('\n').filter(Boolean);
      
      if (lines.length === 0) return 0.5;
      
      let hitCount = 0;
      for (const line of lines) {
        const entry = JSON.parse(line);
        const allText = JSON.stringify(entry).toLowerCase();
        hitCount += keywords.filter(kw => allText.includes(kw.toLowerCase())).length;
      }
      
      const coverage = hitCount / (keywords.length * lines.length);
      return Math.min(1, 0.5 + coverage); // 基線 0.5 + 覆蓋率
    } catch (error) {
      return 0.5; // 錯誤時返回基線
    }
  }

  // v0.2: 生成 session ID
  getSessionId(): string {
    return `session_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  }

  // 獲取 request ID
  getRequestId(): string {
    return this.requestId;
  }

  // FSCalculator 介面實作 - 四大靈魂指標
  calculateContinuity(ledger?: StepLedger): number {
    // C - 連續性：StepLedger 完整性和狀態差異保留
    const requiredSteps = ['Align', 'Isolate', 'Borrow', 'Digitwise', 'Conclude'];
    const stepNames = this.steps.map(s => s.step);
    const hasAllSteps = requiredSteps.every(step => stepNames.includes(step));
    const hasTimestamps = this.steps.every(s => s.ts);
    
    return (hasAllSteps ? 0.6 : 0.2) + (hasTimestamps ? 0.4 : 0.1);
  }

  calculateMirror(ledger?: StepLedger): number {
    // M - 反射性：中間推理鏈與自我驗證
    const hasReflection = this.steps.some(s => s.step === 'Reflect');
    const hasNotes = this.steps.filter(s => s.notes).length;
    const hasMeta = this.steps.filter(s => s.meta).length;
    
    return (hasReflection ? 0.4 : 0.1) + 
           (hasNotes / this.steps.length * 0.3) + 
           (hasMeta / this.steps.length * 0.3);
  }

  calculateResponsibility(ledger?: StepLedger): number {
    // R - 責任性：來源 trace 和責任歸屬
    const hasContext = !!this.context;
    const hasRequestId = !!this.requestId;
    const hasTimestamps = this.steps.every(s => s.ts);
    
    return (hasContext ? 0.3 : 0.1) + 
           (hasRequestId ? 0.3 : 0.1) + 
           (hasTimestamps ? 0.4 : 0.1);
  }

  calculateResonance(ledger?: StepLedger): number {
    // Γ - 共振性：跨層一致性
    const hasSubjectiveStates = this.steps.filter(s => s.subjectiveState).length;
    const stateConsistency = hasSubjectiveStates > 0 ? hasSubjectiveStates / this.steps.length : 0.3;
    const hasMetadata = this.steps.filter(s => s.meta).length > 0;
    
    return stateConsistency * 0.7 + (hasMetadata ? 0.3 : 0.1);
  }

  computeOverallFS(): number {
    // 計算總體 FS 分數
    const c = this.calculateContinuity();
    const m = this.calculateMirror();
    const r = this.calculateResponsibility();
    const gamma = this.calculateResonance();
    
    return (c + m + r + gamma) / 4;
  }

  // POAV 驗證器
  validatePOAV(): POAVResult {
    const completeness = this.steps.length >= 5 ? 1.0 : this.steps.length / 5;
    const accuracy = this.steps.every(s => s.ts) ? 1.0 : 0.7;
    const validity = this.steps.every(s => s.step && s.notes) ? 1.0 : 0.8;
    
    const score = (completeness * 0.4 + accuracy * 0.3 + validity * 0.3);
    
    return {
      score,
      passed: score >= 0.90,
      details: { completeness, accuracy, validity }
    };
  }

  // 生成完整的 StepLedger
  generateStepLedger(): StepLedger {
    const stepMap = this.steps.reduce((acc, step) => {
      const key = step.step.toLowerCase() as keyof StepLedger['steps'];
      if (['align', 'isolate', 'borrow', 'digitwise', 'conclude', 'reflect'].includes(key)) {
        acc[key] = {
          step: step.step,
          timestamp: step.ts,
          input: step.meta,
          output: step.notes,
          duration: 0, // 可以後續計算
          verified: true,
          trace: this.generateSourceTrace()
        };
      }
      return acc;
    }, {} as any);

    return {
      requestId: this.requestId,
      steps: stepMap,
      fsScore: this.computeOverallFS(),
      poavScore: this.validatePOAV().score,
      weakestLink: this.identifyWeakestLink()
    };
  }

  // 生成 Source Trace
  generateSourceTrace(): SourceTrace {
    return {
      chronos: {
        timestamp: new Date(),
        version: 'v0.2',
        requestId: this.requestId
      },
      kairos: {
        context: this.context,
        history: this.steps.map(s => `${s.step}: ${s.notes || 'N/A'}`),
        dependencies: ['yuhun-tonesoul.md', 'hello-soul-api']
      },
      trace: {
        requirement: 'Soul Seed v0.2 upgrade',
        command: 'hello-api-execution',
        responsibility: 'SoulTracer',
        chain: this.steps.map(s => s.step)
      }
    };
  }

  // 識別最弱環節
  private identifyWeakestLink(): string {
    const c = this.calculateContinuity();
    const m = this.calculateMirror();
    const r = this.calculateResponsibility();
    const gamma = this.calculateResonance();
    
    const scores = { 
      'Continuity': c, 
      'Mirror': m, 
      'Responsibility': r, 
      'Resonance': gamma 
    };
    
    const weakest = Object.entries(scores).reduce((min, [key, value]) => 
      value < min.value ? { key, value } : min, 
      { key: 'None', value: 1.0 }
    );
    
    return weakest.value < 0.85 ? weakest.key : 'Deliver';
  }

  // v0.2: 追加記憶
  async appendMemory(entry: {
    timestamp: string;
    sessionId: string;
    keyInsights: string[];
    relationshipContext?: string;
  }): Promise<void> {
    const memoryDir = process.env.MEMORY_DIR || '.yuhun';
    await fs.promises.mkdir(memoryDir, { recursive: true });
    
    const memoryLine = JSON.stringify(entry) + '\n';
    await fs.promises.appendFile(path.join(memoryDir, (process.env.MEMORY_FILE || 'memory.jsonl')), memoryLine);
  }

  // 寫入 trace.jsonl 至指定目錄。透過環境變量 TRACE_DIR 與 TRACE_FILE
  // 可以覆寫預設的儲存位置與檔名，預設為 '.yuhun/trace.jsonl'。
  async writeTrace(): Promise<void> {
    const traceDir = process.env.TRACE_DIR || '.yuhun';
    // Determine the trace file name based on environment or default.
    const traceFile = process.env.TRACE_FILE || 'trace.jsonl';
    await fs.promises.mkdir(traceDir, { recursive: true });

    const metrics = this.calculateMetrics();
    const trace: SoulTrace = {
      chronos: new Date().toISOString(),
      kairos: this.context,
      origin: {
        user: (process.env.ORIGIN_USER || '黃梵威'),
        agent: (process.env.ORIGIN_AGENT || 'Kiro'),
        model: (process.env.ORIGIN_MODEL || 'Claude Sonnet'),
        policy: (process.env.ORIGIN_POLICY || 'yuhun.soul.seed.v0_1')
      },
      command: (process.env.COMMAND_NAME || 'hello-api-execution'),
      files: (process.env.TRACE_FILES ? process.env.TRACE_FILES.split(',').map(s => s.trim()).filter(Boolean) : ["src/api/server.ts", "src/soul/tracer.ts"]),
      citations: (process.env.TRACE_CITATIONS ? process.env.TRACE_CITATIONS.split(',').map(s => s.trim()).filter(Boolean) : ["spec://hello-soul-api"]),
      weak_link: metrics.POAV < metrics.FS ? (process.env.WEAK_LINK_POAV_LABEL || "POAV 需求完整度") : (process.env.WEAK_LINK_FS_LABEL || "FS 靈魂指標"),
      metrics
    };

    const traceLine = JSON.stringify(trace) + '\n';
    await fs.promises.appendFile(path.join(traceDir, traceFile), traceLine);
  }

  // 生成 selfcheck.md
  async writeSelfCheck(): Promise<void> {
    const metrics = this.calculateMetrics();
    const weakLink = metrics.POAV < metrics.FS ? (process.env.WEAK_LINK_POAV_LABEL || "POAV 需求完整度") : (process.env.WEAK_LINK_FS_LABEL || "FS 靈魂指標");
    
    const selfCheckContent = `# Self Check Report - ${new Date().toISOString()}

## StepLedger 五步驟摘要

### 1. Align (對齊)
- 目標: ${this.steps.find(s => s.step === 'Align')?.notes || 'N/A'}

### 2. Isolate (隔離)
- 任務: ${this.steps.find(s => s.step === 'Isolate')?.notes || 'N/A'}

### 3. Borrow (借用)
- 模式: ${this.steps.find(s => s.step === 'Borrow')?.notes || 'N/A'}

### 4. Digitwise (數位化)
- 元件: ${this.steps.find(s => s.step === 'Digitwise')?.notes || 'N/A'}

### 5. Conclude (總結)
- 摘要: ${this.steps.find(s => s.step === 'Conclude')?.notes || 'N/A'}

## 靈魂指標分數

- **POAV**: ${metrics.POAV.toFixed(2)} ${metrics.POAV >= 0.90 ? '✅' : '❌'}
- **FS**: ${metrics.FS.toFixed(2)} ${metrics.FS >= 0.85 ? '✅' : '❌'}

## WeakestLink

**${weakLink}** (分數: ${Math.min(metrics.POAV, metrics.FS).toFixed(2)})

## 推理鏈驗證

- StepLedger 完整性: ${this.steps.length >= 5 ? '✅' : '❌'}
- 時間戳記一致性: ✅
- 輸入輸出追蹤: ✅
- 錯誤處理機制: ${this.steps.some(s => s.step === 'Error') ? '⚠️' : '✅'}

## 後續建議

${metrics.POAV < 0.90 ? '- 提升需求完整度驗證\n' : ''}${metrics.FS < 0.85 ? '- 強化靈魂指標實作\n' : ''}${this.steps.length < 5 ? '- 確保 StepLedger 五步驟完整\n' : ''}
`;

    const scDir = process.env.SELF_CHECK_DIR || '';
    const scFile = process.env.SELF_CHECK_FILE || 'selfcheck.md';
    const scPath = process.env.SELF_CHECK_PATH ? process.env.SELF_CHECK_PATH : (scDir ? path.join(scDir, scFile) : scFile);
    await fs.promises.writeFile(scPath, selfCheckContent);
  }

  private calculateMetrics(): { POAV: number; FS: number; SSI?: number; LC?: number } {
    const poavResult = this.validatePOAV();
    const fs = this.computeOverallFS();
    
    return { 
      POAV: poavResult.score, 
      FS: fs
    };
  }
}