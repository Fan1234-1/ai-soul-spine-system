import { StepRecord } from '../types/soul';

export interface Metrics {
  POAV: number;
  FS: number;
}

export function calculateMetrics(steps: StepRecord[]): Metrics {
  // POAV (需求完整度) 計算
  const requiredSteps = ['Align', 'Isolate', 'Borrow', 'Digitwise', 'Conclude'];
  const stepNames = steps.map(s => s.step);
  const hasRequiredSteps = requiredSteps.every(step => stepNames.includes(step));
  const hasValidInputs = steps.every(s => s.input !== undefined);
  const hasTimestamps = steps.every(s => s.timestamp !== undefined);
  const hasCompleteStructure = steps.length >= 5;
  
  let POAV = 0.7; // 基礎分數
  if (hasRequiredSteps) POAV += 0.1;
  if (hasValidInputs) POAV += 0.1;
  if (hasTimestamps) POAV += 0.05;
  if (hasCompleteStructure) POAV += 0.05;

  // FS (靈魂指標) 計算 - C, M, R, Γ
  // C - 連續性 (Continuity): StepLedger 完整性
  const continuity = hasRequiredSteps && hasCompleteStructure ? 0.22 : 0.15;
  
  // M - 反射性 (Mirror): 輸入輸出完整性
  const mirror = hasValidInputs && steps.some(s => s.output) ? 0.22 : 0.15;
  
  // R - 責任性 (Responsibility): 時間戳記和追蹤
  const responsibility = hasTimestamps && steps.every(s => s.step && s.timestamp) ? 0.22 : 0.15;
  
  // Γ - 共振性 (Resonance): 系統一致性
  const resonance = steps.some(s => s.output) && steps.some(s => s.duration !== undefined) ? 0.22 : 0.15;
  
  const FS = continuity + mirror + responsibility + resonance;

  return { 
    POAV: Math.min(POAV, 1.0), 
    FS: Math.min(FS, 1.0) 
  };
}