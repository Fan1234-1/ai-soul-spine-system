// StepLedger 管理系統單元測試
import { StepLedgerManager, StepName } from '../soul/stepLedger';

describe('StepLedgerManager', () => {
  let manager: StepLedgerManager;

  beforeEach(() => {
    manager = new StepLedgerManager('test-context');
  });

  describe('基礎功能測試', () => {
    test('應該能夠記錄單個步驟', () => {
      const result = manager.recordStep('Align', { goal: 'test' }, 'aligned');

      expect(result.isValid).toBe(true);
      expect(result.errors).toHaveLength(0);
      expect(manager.getCurrentStep()).toBe('Align');
    });

    test('應該能夠按順序記錄所有步驟', () => {
      const steps: StepName[] = ['Align', 'Isolate', 'Borrow', 'Digitwise', 'Conclude', 'Reflect'];

      for (const step of steps) {
        const result = manager.recordStep(step, { step }, `completed ${step}`);
        expect(result.isValid).toBe(true);
      }

      expect(manager.getAllSteps().size).toBe(6);
      expect(manager.getCurrentStep()).toBe('Reflect');
    });

    test('應該能夠獲取步驟記錄', () => {
      manager.recordStep('Align', { test: true }, 'test output');

      const step = manager.getStep('Align');
      expect(step).toBeDefined();
      expect(step?.step).toBe('Align');
      expect(step?.input).toEqual({ test: true });
      expect(step?.output).toBe('test output');
    });
  });

  describe('步驟驗證測試', () => {
    test('應該檢測依賴關係違反', () => {
      // 嘗試在沒有 Align 的情況下記錄 Isolate
      const result = manager.recordStep('Isolate', {}, 'isolated');

      expect(result.isValid).toBe(false);
      expect(result.errors).toContain('步驟 Isolate 依賴 Align，但 Align 尚未完成');
    });

    test('應該警告步驟順序異常', () => {
      manager.recordStep('Align', {}, 'aligned');
      manager.recordStep('Isolate', {}, 'isolated');
      manager.recordStep('Borrow', {}, 'borrowed');

      // 回到之前的步驟
      const result = manager.recordStep('Align', {}, 'realigned');

      expect(result.isValid).toBe(true);
      expect(result.warnings).toContain('步驟 Align 已存在，將覆蓋原有記錄');
    });

    test('應該警告跳過中間步驟', () => {
      manager.recordStep('Align', {}, 'aligned');

      // 跳過 Isolate 直接到 Borrow
      const result = manager.recordStep('Borrow', {}, 'borrowed');

      expect(result.isValid).toBe(false); // 因為缺少依賴
      expect(result.errors).toContain('步驟 Borrow 依賴 Isolate，但 Isolate 尚未完成');
    });
  });

  describe('完整性驗證測試', () => {
    test('應該檢測缺少必要步驟', () => {
      manager.recordStep('Align', {}, 'aligned');
      manager.recordStep('Isolate', {}, 'isolated');
      // 缺少其他步驟

      const validation = manager.validateCompleteness();

      expect(validation.isValid).toBe(false);
      expect(validation.errors).toContain('缺少必要步驟：Borrow');
      expect(validation.errors).toContain('缺少必要步驟：Digitwise');
      expect(validation.errors).toContain('缺少必要步驟：Conclude');
    });

    test('應該建議加入 Reflect 步驟', () => {
      // 記錄所有必要步驟但不包含 Reflect
      const requiredSteps: StepName[] = ['Align', 'Isolate', 'Borrow', 'Digitwise', 'Conclude'];
      for (const step of requiredSteps) {
        manager.recordStep(step, {}, `completed ${step}`);
      }

      const validation = manager.validateCompleteness();

      expect(validation.isValid).toBe(true);
      expect(validation.warnings).toContain('建議加入 Reflect 步驟以符合 v0.2 規範');
    });

    test('完整的 v0.2 StepLedger 應該通過驗證', () => {
      const allSteps: StepName[] = ['Align', 'Isolate', 'Borrow', 'Digitwise', 'Conclude', 'Reflect'];
      for (const step of allSteps) {
        manager.recordStep(step, { step }, `completed ${step}`);
      }

      const validation = manager.validateCompleteness();

      expect(validation.isValid).toBe(true);
      expect(validation.errors).toHaveLength(0);
      expect(validation.warnings).toHaveLength(0);
    });
  });

  describe('StepLedger 生成測試', () => {
    test('應該生成完整的 StepLedger', () => {
      const allSteps: StepName[] = ['Align', 'Isolate', 'Borrow', 'Digitwise', 'Conclude', 'Reflect'];
      for (const step of allSteps) {
        manager.recordStep(step, { step }, `completed ${step}`);
      }

      const stepLedger = manager.generateStepLedger();

      expect(stepLedger.requestId).toBeDefined();
      expect(stepLedger.steps.align).toBeDefined();
      expect(stepLedger.steps.isolate).toBeDefined();
      expect(stepLedger.steps.borrow).toBeDefined();
      expect(stepLedger.steps.digitwise).toBeDefined();
      expect(stepLedger.steps.conclude).toBeDefined();
      expect(stepLedger.steps.reflect).toBeDefined();
      expect(stepLedger.fsScore).toBeGreaterThan(0);
      expect(stepLedger.poavScore).toBeGreaterThan(0);
    });

    test('應該計算正確的分數', () => {
      // 記錄完整的步驟
      const allSteps: StepName[] = ['Align', 'Isolate', 'Borrow', 'Digitwise', 'Conclude', 'Reflect'];
      for (const step of allSteps) {
        manager.recordStep(step, { step }, `completed ${step}`);
      }

      const stepLedger = manager.generateStepLedger();

      // 完整的 StepLedger 應該有高分
      expect(stepLedger.fsScore).toBeGreaterThanOrEqual(0.9);
      expect(stepLedger.poavScore).toBeGreaterThanOrEqual(0.9);
      expect(stepLedger.weakestLink).toBe('Deliver');
    });
  });

  describe('統計功能測試', () => {
    test('應該提供正確的統計資訊', () => {
      manager.recordStep('Align', {}, 'aligned');
      manager.recordStep('Isolate', {}, 'isolated');
      manager.recordStep('Borrow', {}, 'borrowed');

      const stats = manager.getStatistics();

      expect(stats.totalSteps).toBe(6); // v0.2 包含 Reflect
      expect(stats.completedSteps).toBe(3);
      expect(stats.completionRate).toBe(0.5);
    });
  });

  describe('向後相容性測試', () => {
    test('應該能夠匯出為 TraceStep 格式', () => {
      manager.recordStep('Align', { test: true }, 'aligned');
      manager.recordStep('Isolate', { scope: 'test' }, 'isolated');

      const traceSteps = manager.exportAsTraceSteps();

      expect(traceSteps).toHaveLength(2);
      expect(traceSteps[0].step).toBe('Align');
      expect(traceSteps[0].meta).toEqual({ test: true });
      expect(traceSteps[0].notes).toBe('aligned');
    });

    test('應該能夠從 TraceStep 格式匯入', () => {
      const traceSteps = [
        { step: 'Align', notes: 'aligned', ts: new Date().toISOString(), meta: { test: true } },
        { step: 'Isolate', notes: 'isolated', ts: new Date().toISOString(), meta: { scope: 'test' } }
      ];

      manager.importFromTraceSteps(traceSteps);

      expect(manager.getAllSteps().size).toBe(2);
      expect(manager.getStep('Align')).toBeDefined();
      expect(manager.getStep('Isolate')).toBeDefined();
    });
  });

  describe('錯誤處理測試', () => {
    test('應該處理無效的步驟名稱', () => {
      const traceSteps = [
        { step: 'InvalidStep', notes: 'invalid', ts: new Date().toISOString(), meta: {} }
      ];

      manager.importFromTraceSteps(traceSteps);

      expect(manager.getAllSteps().size).toBe(0);
    });

    test('應該能夠重置 StepLedger', () => {
      manager.recordStep('Align', {}, 'aligned');
      manager.recordStep('Isolate', {}, 'isolated');

      expect(manager.getAllSteps().size).toBe(2);

      manager.reset();

      expect(manager.getAllSteps().size).toBe(0);
      expect(manager.getCurrentStep()).toBeNull();
      expect(manager.getTransitions()).toHaveLength(0);
    });
  });
});