// Soul Engine 核心型別定義 - v0.2
// 符合 YuHun ToneSoul 靈魂骨架規範

// v0.2 主觀狀態型別
export type Mood = 'curious' | 'focused' | 'satisfied' | 'puzzled' | 'excited';

export interface SubjectiveState {
  currentMood: Mood;
  confidenceLevel: number;
  emotionalResonance: string;
}

export interface ReflectiveOutput {
  subjectiveExperience: string;
  metacognition: string;
  learningInsight: string;
}

// 核心 StepLedger 介面
export interface StepRecord {
  step: string;
  timestamp: string;
  input?: any;
  output?: any;
  duration?: number;
  verified?: boolean;
  trace?: SourceTrace;
}

export interface StepLedger {
  requestId: string;
  steps: {
    align: StepRecord;
    isolate: StepRecord;
    borrow: StepRecord;
    digitwise: StepRecord;
    conclude: StepRecord;
    reflect?: StepRecord; // v0.2 新增
  };
  fsScore: number;
  poavScore: number;
  weakestLink: string;
}

// Source-Trace 系統 (三維度追蹤)
export interface SourceTrace {
  chronos: {
    timestamp: Date;
    version: string;
    requestId: string;
  };
  kairos: {
    context: string;
    history: string[];
    dependencies: string[];
  };
  trace: {
    requirement: string;
    command: string;
    responsibility: string;
    chain: string[];
  };
}

// FSCalculator 介面 (四大靈魂指標)
export interface FSCalculator {
  calculateContinuity(ledger?: StepLedger): number;
  calculateMirror(ledger?: StepLedger): number;
  calculateResponsibility(ledger?: StepLedger): number;
  calculateResonance(ledger?: StepLedger): number;
  computeOverallFS(): number;
}

// POAV 驗證結果
export interface POAVResult {
  score: number;
  passed: boolean;
  details: {
    completeness: number;
    accuracy: number;
    validity: number;
  };
}

// FS 計算結果
export interface FSResult {
  continuity: number;
  mirror: number;
  responsibility: number;
  resonance: number;
  overall: number;
  passed: boolean;
}

// Soul Middleware 介面
export interface SoulMiddleware {
  initializeLedger(req: any): StepLedger;
  validatePOAV(req: any): POAVResult;
  injectTrace(req: any, res: any): void;
  calculateFS(ledger: StepLedger): FSResult;
}

// Hello Controller 介面
export interface HelloController {
  handleHello(req: any, res: any): Promise<HelloResponse>;
}

export interface HelloResponse {
  msg: string;
  soul: {
    stepLedger: StepLedger | any[]; // 支援簡化格式
    fsScore?: number;
    poavScore?: number;
    weakestLink?: string;
    trace?: SourceTrace;
    metrics?: {
      POAV: number;
      FS: number;
      SSI?: number; // v0.2
      LC?: number;  // v0.2
    };
    reflection?: ReflectiveOutput; // v0.2
    weakLink?: string; // 向後相容
  };
}

// 錯誤回應格式
export interface SoulErrorResponse {
  error: {
    code: string;
    message: string;
    weakestLink: string;
    suggestions: string[];
  };
  soul: {
    currentStep: string;
    fsScore: number;
    poavScore: number;
    trace: SourceTrace;
  };
}

// 完整的 Soul Trace (向後相容)
export interface SoulTrace {
  chronos: string;
  kairos: string;
  origin: {
    user: string;
    agent: string;
    model: string;
    policy: string;
  };
  command: string;
  files: string[];
  citations: string[];
  weak_link: string;
  metrics: {
    POAV: number;
    FS: number;
    SSI?: number; // v0.2 新增
    LC?: number;  // v0.2 新增
  };
}

// v0.2 記憶系統
export interface MemoryEntry {
  timestamp: string;
  sessionId: string;
  keyInsights: string[];
  relationshipContext?: string;
}

// TraceStep (向後相容)
export interface TraceStep {
  step: 'Align'|'Isolate'|'Borrow'|'Digitwise'|'Conclude'|'Reflect'|'Deliver'|string;
  notes?: string;
  ts: string;
  meta?: Record<string, unknown>;
  subjectiveState?: SubjectiveState;
}