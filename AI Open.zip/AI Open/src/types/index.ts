export type StepName = "Align" | "Isolate" | "Borrow" | "Digitwise" | "Conclude";

export interface StepEntry {
  name: StepName;
  notes: string;
  ts: string; // ISO8601
}

export interface StepLedger {
  steps: StepEntry[];
  add(name: StepName, notes: string): void;
}

export interface Metrics {
  POAV: number;
  FS: number;
}

export interface SourceTrace {
  chronos: string;
  kairos: string;
  origin: {
    user: string;
    agent: string;
    model: string;
    policy: string;
  };
  command: string;
  files: string[];
  citations: string[];
  weak_link: string;
  metrics: Metrics;
}

export interface SoulSummary {
  stepLedger: StepEntry[];
  metrics: Metrics;
  weakLink: string;
}