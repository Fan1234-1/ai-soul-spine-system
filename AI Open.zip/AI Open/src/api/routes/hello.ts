import { Router, Request, Response } from "express";

const r = Router();

r.get("/hello", (req: Request, res: Response) => {
  const soul = (req as any).__soul__;
  return res.status(200).json({
    msg: "Hello Soul",
    soul, // 帶上 StepLedger/metrics/WeakestLink
  });
});

export default r;