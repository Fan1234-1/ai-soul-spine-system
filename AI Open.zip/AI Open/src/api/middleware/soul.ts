import { Request, Response, NextFunction } from "express";
import { runSoulPipeline } from "../../soul/bridge";

export function soulMiddleware(req: Request, res: Response, next: NextFunction) {
  // 僅示範：每次請求都跑最小語魂流程（實務可依路由精細化）
  const summary = runSoulPipeline("http-request", ["src/api/routes/hello.ts"]);
  // 若不達門檻，阻擋交付（這裡示範通過門檻，evaluate() 給了 0.92/0.87）
  if (summary.metrics.POAV < 0.90 || summary.metrics.FS < 0.85) {
    return res.status(422).json({
      error: "SoulGateFailed",
      detail: summary,
    });
  }
  // 暫存到 req 讓 handler 使用
  (req as any).__soul__ = summary;
  next();
}