import request from 'supertest';
import { app } from '../src/api/server';
import * as fs from 'fs';

jest.setTimeout(15000); // 減少誤判超時（5s → 15s）

describe('Hello Soul API', () => {
  describe('GET /hello', () => {
    it('should return Hello Soul message with soul data', async () => {
      const res = await request(app).get('/hello').expect(200);
      expect(res.body.msg).toBe('Hello Soul');
      expect(res.body.soul?.metrics?.POAV).toBeGreaterThanOrEqual(0.90);
      expect(res.body.soul?.metrics?.FS).toBeGreaterThanOrEqual(0.85);
    });

    it('should include valid StepLedger with all 5 steps', async () => {
      const res = await request(app).get('/hello').expect(200);
      const steps = res.body.soul?.stepLedger;
      expect(Array.isArray(steps)).toBe(true);
      expect(steps).toHaveLength(5);
      const names = steps.map((s: any) => s.step);
      expect(names).toEqual(['Align', 'Isolate', 'Borrow', 'Digitwise', 'Conclude']);
    });

    it('should meet soul metrics requirements (POAV ≥ 0.90, FS ≥ 0.85)', async () => {
      const res = await request(app).get('/hello').expect(200);
      const { metrics } = res.body.soul;
      expect(metrics).toHaveProperty('POAV');
      expect(metrics).toHaveProperty('FS');
      
      // 驗證靈魂指標門檻
      expect(metrics.POAV).toBeGreaterThanOrEqual(0.90);
      expect(metrics.FS).toBeGreaterThanOrEqual(0.85);
    });

    it('should identify weakest link correctly', async () => {
      const res = await request(app).get('/hello').expect(200);
      const { metrics, weakLink } = res.body.soul;
      expect(typeof weakLink).toBe('string');
      expect(weakLink.length).toBeGreaterThan(0);
    });

    it('should generate trace.jsonl file', async () => {
      await request(app).get('/hello').expect(200);
      
      // 檢查 trace.jsonl 是否存在
      expect(fs.existsSync('.yuhun/trace.jsonl')).toBe(true);
      
      // 讀取最後一行
      const traceContent = fs.readFileSync('.yuhun/trace.jsonl', 'utf-8');
      const lines = traceContent.trim().split('\n');
      const lastLine = JSON.parse(lines[lines.length - 1]);
      
      expect(lastLine).toHaveProperty('chronos');
      expect(lastLine).toHaveProperty('kairos');
      expect(lastLine).toHaveProperty('metrics');
      expect(lastLine.metrics.POAV).toBeGreaterThanOrEqual(0.90);
      expect(lastLine.metrics.FS).toBeGreaterThanOrEqual(0.85);
    });

    it('should generate selfcheck.md file', async () => {
      await request(app).get('/hello').expect(200);
      
      // 檢查 selfcheck.md 是否存在
      expect(fs.existsSync('selfcheck.md')).toBe(true);
      
      const selfCheckContent = fs.readFileSync('selfcheck.md', 'utf-8');
      expect(selfCheckContent).toContain('StepLedger 五步驟摘要');
      expect(selfCheckContent).toContain('POAV');
      expect(selfCheckContent).toContain('FS');
      expect(selfCheckContent).toContain('WeakestLink');
    });
  });

  describe('GET /', () => {
    it('should return health check with soul status', async () => {
      const res = await request(app).get('/').expect(200);
      expect(res.body).toHaveProperty('status');
      expect(res.body).toHaveProperty('soul');
      expect(res.body).toHaveProperty('policy', 'yuhun.soul.seed.v0_1');
    });
  });

  // 清理測試產生的檔案
  afterAll(async () => {
    try {
      if (fs.existsSync('.yuhun')) {
        fs.rmSync('.yuhun', { recursive: true, force: true });
      }
      if (fs.existsSync('selfcheck.md')) {
        fs.rmSync('selfcheck.md', { force: true });
      }
    } catch (error) {
      // 忽略清理錯誤
    }
  });
});